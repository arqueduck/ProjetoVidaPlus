from .auth import router as auth_router
from .patients import router as patients_router
from .professionals import router as professionals_router
from .units import router as units_router
from .consultations import router as consultations_router
from .medical_records import router as medical_records_router