from .user import User
from .patient import Paciente
from .professional import Profissional
from .unit import Unidade
from .consultation import Consulta
from .medical_record import Prontuario 